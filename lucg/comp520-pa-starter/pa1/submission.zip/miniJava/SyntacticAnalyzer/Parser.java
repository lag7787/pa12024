package miniJava.SyntacticAnalyzer;

import miniJava.ErrorReporter;

public class Parser {
	private Scanner _scanner;
	private ErrorReporter _errors;
	private Token _currentToken;
	private boolean trace = false;
	
	public Parser( Scanner scanner, ErrorReporter errors ) {
		this._scanner = scanner;
		this._errors = errors;
		this._currentToken = this._scanner.scan();
	}
	
	class SyntaxError extends Error {
		private static final long serialVersionUID = -6461942006097999362L;
	}
	
	public void parse() {
		try {
			// The first thing we need to parse is the Program symbol
			parseProgram();
		} catch( SyntaxError e ) {}
	}
	
	// Program ::= (ClassDeclaration)* eot
	private void parseProgram() throws SyntaxError {
		while (this._currentToken.getTokenType() == TokenType.CLASS) {
			parseClassDeclaration();
		}
		accept(TokenType.EOT);	
		return;
	}
	
// ClassDeclaration ::= class identifier { (FieldDeclaration|MethodDeclaration)* }
/* 
	* ::= class id 
	{ 
		( 
			( public | private )?  (static)?  
				(
					Type id ( ; | L )  
					| void id L 
				)
		)* 
	} 
*/
	private void parseClassDeclaration() throws SyntaxError {
		accept(TokenType.CLASS);
		accept(TokenType.IDENTIFIER);
		accept(TokenType.LBRACKET);
		while (
				this._currentToken.getTokenType() == TokenType.PUBLIC ||
				this._currentToken.getTokenType() == TokenType.PRIVATE ||
				this._currentToken.getTokenType() == TokenType.STATIC ||
				this._currentToken.getTokenType() == TokenType.VOID ||
				this._currentToken.getTokenType() == TokenType.BOOLEAN ||
				this._currentToken.getTokenType() == TokenType.INT ||
				this._currentToken.getTokenType() == TokenType.IDENTIFIER
				) {
			
			if (this._currentToken.getTokenType() == TokenType.PUBLIC || this._currentToken.getTokenType() == TokenType.PRIVATE) {
				acceptIt();
			}
			
			if (this._currentToken.getTokenType() == TokenType.STATIC) {
				acceptIt();
			}
			
			if (this._currentToken.getTokenType() == TokenType.VOID) {
				acceptIt();
				accept(TokenType.IDENTIFIER);
				parseL();
			} else {
				parseType();
				accept(TokenType.IDENTIFIER);
				if (this._currentToken.getTokenType() == TokenType.SEMICOLON) acceptIt();
				else parseL();
			}
		}
		accept(TokenType.RBRACKET);
		return;
	}

	/*
	Statement ::=
	{Statement*}
	| ( int ('' | []) | boolean) id = Expression ;
	| id (
		| id = Expression ;
		| = Expression ;
		| [] id = Expression ;
		| [ Expression ] = Expression ;
		| (ArugmentList?) ;
		| .id (.id)* J
		)
	| this (.id)* J
	| return Expression? ; 
	| if ( Expression ) Statement ( else Statement ) ?
	| while ( Expression ) Statement
	*/

	private void parseStatement() throws SyntaxError {
		switch(this._currentToken.getTokenType()) {
		case LBRACKET:
			acceptIt();
			while (
					this._currentToken.getTokenType() == TokenType.LBRACKET ||
					this._currentToken.getTokenType() == TokenType.INT ||
					this._currentToken.getTokenType() == TokenType.BOOLEAN ||
					this._currentToken.getTokenType() == TokenType.THIS ||
					this._currentToken.getTokenType() == TokenType.IDENTIFIER ||
					this._currentToken.getTokenType() == TokenType.IF ||
					this._currentToken.getTokenType() == TokenType.RETURN ||
					this._currentToken.getTokenType() == TokenType.WHILE
					) {
				parseStatement();
			}
			accept(TokenType.RBRACKET);
			return;
		case INT: case BOOLEAN:
			if (this._currentToken.getTokenType() == TokenType.INT) {
				acceptIt();
				if (this._currentToken.getTokenType() == TokenType.SQLBRACKET) {
					acceptIt();
					accept(TokenType.SQRBRACKET);
				}
			} else acceptIt();
			accept(TokenType.IDENTIFIER);
			accept(TokenType.ASSIGNMENT);
			parseExpression();
			accept(TokenType.SEMICOLON);
			return;
		case THIS:
			acceptIt();
			while (this._currentToken.getTokenType() == TokenType.DOT) {
				acceptIt();
				accept(TokenType.IDENTIFIER);			
			}
			parseJ();
			accept(TokenType.SEMICOLON);
			return;
		case IDENTIFIER:
			acceptIt();
			switch(this._currentToken.getTokenType()) {
			case IDENTIFIER:
				acceptIt();
				accept(TokenType.ASSIGNMENT);
				parseExpression();
				accept(TokenType.SEMICOLON);
				break;
			case ASSIGNMENT:
				acceptIt();
				parseExpression();
				accept(TokenType.SEMICOLON);
				break;
			case SQLBRACKET:
				acceptIt();
				if (this._currentToken.getTokenType() == TokenType.SQRBRACKET) {
					acceptIt();
					accept(TokenType.IDENTIFIER);
				} else {
					parseExpression();
					accept(TokenType.SQRBRACKET);
				}
				accept(TokenType.ASSIGNMENT);
				parseExpression();
				accept(TokenType.SEMICOLON);
				break;
			case LPAREN:
				acceptIt();
				//too lazy to determine expression starters rn
				if (
					this._currentToken.getTokenType() == TokenType.NUMBER ||
					this._currentToken.getTokenType() == TokenType.FALSE ||
					this._currentToken.getTokenType() == TokenType.TRUE ||
					this._currentToken.getTokenType() == TokenType.NEW ||
					this._currentToken.getTokenType() == TokenType.LPAREN ||
					this._currentToken.getTokenType() == TokenType.IDENTIFIER ||
					this._currentToken.getTokenType() == TokenType.THIS ||
					this._currentToken.getTokenText() == "!" ||
					this._currentToken.getTokenText() == "-"
				) {
					parseArgumentList();
				}
				accept(TokenType.RPAREN);
				accept(TokenType.SEMICOLON);
				break;
			case DOT:
				acceptIt();
				accept(TokenType.IDENTIFIER);
				while (this._currentToken.getTokenType() == TokenType.DOT) {
					acceptIt();
					accept(TokenType.IDENTIFIER);
				}
				parseJ();
				accept(TokenType.SEMICOLON);
				break;
			default:
				parseError("Invalid Term - found " + this._currentToken.getTokenType());
				return;
			}
			return;
		case RETURN:
			acceptIt();
			// expression starters
			if (
				this._currentToken.getTokenType() == TokenType.NUMBER ||
				this._currentToken.getTokenType() == TokenType.FALSE ||
				this._currentToken.getTokenType() == TokenType.TRUE ||
				this._currentToken.getTokenType() == TokenType.NEW ||
				this._currentToken.getTokenType() == TokenType.LPAREN ||
				this._currentToken.getTokenType() == TokenType.IDENTIFIER ||
				this._currentToken.getTokenType() == TokenType.THIS ||
				this._currentToken.getTokenText() == "!" ||
				this._currentToken.getTokenText() == "-"
			) parseExpression();
			//accept(TokenType.RPAREN);
			accept(TokenType.SEMICOLON);
			return;
		case IF:
			acceptIt();
			accept(TokenType.LPAREN);
			parseExpression();
			accept(TokenType.RPAREN);
			parseStatement();
			if (this._currentToken.getTokenType() == TokenType.ELSE) {
				acceptIt();
				parseStatement();
			}
			return;
		case WHILE:
			acceptIt();
			accept(TokenType.LPAREN);
			parseExpression();
			accept(TokenType.RPAREN);
			parseStatement();
			return;
			
		default:
			parseError("Invalid Term - found " + this._currentToken.getTokenType());
			return;
		}
	}

	/* 
	 * Expression ::=
		( Id | this ) ( . id )* (  | [ Expression ] | '('(Expression ( , Expression )*)? ')' )

		| unop Expression
		| ( Expression )
		| num | true | false | new ( id() | … | … )
		(binop Expression)*
	 */

	private void parseExpression() throws SyntaxError {

		switch (this._currentToken.getTokenType()) {
			// need to make a choice up here first 
		case IDENTIFIER: case THIS:
			acceptIt();
			while (this._currentToken.getTokenType() == TokenType.DOT) {
				acceptIt();
				accept(TokenType.IDENTIFIER);
			}
			if (this._currentToken.getTokenType() == TokenType.SQLBRACKET) {
				acceptIt();
				parseExpression();
				accept(TokenType.SQRBRACKET);
			} else if (this._currentToken.getTokenType() == TokenType.LPAREN) {
				acceptIt();
				if (
					this._currentToken.getTokenType() == TokenType.NUMBER ||
					this._currentToken.getTokenType() == TokenType.FALSE ||
					this._currentToken.getTokenType() == TokenType.TRUE ||
					this._currentToken.getTokenType() == TokenType.NEW ||
					this._currentToken.getTokenType() == TokenType.LPAREN ||
					this._currentToken.getTokenType() == TokenType.IDENTIFIER ||
					this._currentToken.getTokenType() == TokenType.THIS ||
					this._currentToken.getTokenText() == "!" ||
					this._currentToken.getTokenText() == "-"
				) {
					parseArgumentList();
				}
				accept(TokenType.RPAREN);
			}
			break;
		case LPAREN:
			acceptIt();
			parseExpression();
			accept(TokenType.RPAREN);
			break;
		case NEW:
			acceptIt();
			if (this._currentToken.getTokenType() == TokenType.IDENTIFIER) {
				acceptIt();
				if (this._currentToken.getTokenType() == TokenType.LPAREN) {
					acceptIt();
					accept(TokenType.RPAREN);
				} else {
					accept(TokenType.SQLBRACKET);
					parseExpression();
					accept(TokenType.SQRBRACKET);
				}
			} else {
				accept(TokenType.INT);
				accept(TokenType.SQLBRACKET);
				parseExpression();
				accept(TokenType.SQRBRACKET);
			}
			break;
		case NUMBER: case TRUE: case FALSE:
			acceptIt();
			break;
		case OPERATOR:
			if (this._currentToken.getTokenText().equals("!") || this._currentToken.getTokenText().equals("-")) {
				acceptIt();
				parseExpression();
			} else {
				parseError("Invalid Term - found binary " + this._currentToken.getTokenType());
			}
			break;
		default:
			parseError("Invalid Term - found " + this._currentToken.getTokenType());
			break;
		}
		// do we have to fix this?
		while (this._currentToken.getTokenType() == TokenType.OPERATOR && !this._currentToken.getTokenText().equals("!")) {
			acceptIt();
			parseExpression();
		}
		return;
		
	}

	// J:: = ( = Expression | [ Expression ] = Expression | (ArgumetnList?) ))
	private void parseJ() throws SyntaxError {
		switch(this._currentToken.getTokenType()) {
		case ASSIGNMENT:
			acceptIt();
			parseExpression();
			return;
		case SQLBRACKET:
			acceptIt();
			parseExpression();
			accept(TokenType.SQRBRACKET);
			accept(TokenType.ASSIGNMENT);
			parseExpression();
			return;
		case LPAREN:
			acceptIt();
			if (
					this._currentToken.getTokenType() == TokenType.NUMBER ||
					this._currentToken.getTokenType() == TokenType.FALSE ||
					this._currentToken.getTokenType() == TokenType.TRUE ||
					this._currentToken.getTokenType() == TokenType.NEW ||
					this._currentToken.getTokenType() == TokenType.LPAREN ||
					this._currentToken.getTokenType() == TokenType.IDENTIFIER ||
					this._currentToken.getTokenType() == TokenType.THIS ||
					this._currentToken.getTokenText() == "!" ||
					this._currentToken.getTokenText() == "-"
			) {
				parseArgumentList();
			}
			accept(TokenType.RPAREN);
			return;
		default:
			parseError("Invalid Term - found " + this._currentToken.getTokenType());
			return;
		}
	}

	// L ::= '(' ParameterList? ')' {Statement*}
	private void parseL() throws SyntaxError {
		
		accept(TokenType.LPAREN);
		if (
				this._currentToken.getTokenType() == TokenType.INT ||
				this._currentToken.getTokenType() == TokenType.BOOLEAN ||
				this._currentToken.getTokenType() == TokenType.IDENTIFIER
				) {
				parseParameterList();
			}
		accept(TokenType.RPAREN);
		accept(TokenType.LBRACKET);
		while (
				this._currentToken.getTokenType() == TokenType.LBRACKET ||
				this._currentToken.getTokenType() == TokenType.INT ||
				this._currentToken.getTokenType() == TokenType.BOOLEAN ||
				this._currentToken.getTokenType() == TokenType.THIS ||
				this._currentToken.getTokenType() == TokenType.IDENTIFIER ||
				this._currentToken.getTokenType() == TokenType.IF ||
				this._currentToken.getTokenType() == TokenType.RETURN ||
				this._currentToken.getTokenType() == TokenType.WHILE
				) {
			parseStatement();
		}
		accept(TokenType.RBRACKET);
		return;
	}

	//ArgumentList ::= Expression ( , Expression )*
	private void parseArgumentList() throws SyntaxError {
		parseExpression();
		while (this._currentToken.getTokenType() == TokenType.COMMA) {
			acceptIt();
			parseExpression();
		}
	}

	//ParameterList ::= Type id ( , Type id )* 
	private void parseParameterList() throws SyntaxError {
		
		parseType();
		accept(TokenType.IDENTIFIER);
		while(this._currentToken.getTokenType() == TokenType.COMMA) {
			acceptIt();
			parseType();
			accept(TokenType.IDENTIFIER);
		}
	}

	//Type ::= int (  | [] ) | id (  | [] ) | boolean
	private void parseType() throws SyntaxError {
		switch(this._currentToken.getTokenType()) {
		case INT: case IDENTIFIER:
			acceptIt();
			if (this._currentToken.getTokenType() == TokenType.SQLBRACKET) {
				acceptIt();
				accept(TokenType.SQRBRACKET);
			}
			return;
		case BOOLEAN:
			acceptIt();
			return;
		default:
			parseError("Invalid Term - found " + this._currentToken.getTokenType());
			return;
		} 
	}
	
	// This method will accept the token and retrieve the next token.
	//  Can be useful if you want to error check and accept all-in-one.
	private void accept(TokenType expectedType) throws SyntaxError {
		if( _currentToken.getTokenType() == expectedType ) {
			if (trace) {
				pTrace();
			}
			_currentToken = _scanner.scan();
			return;
		} else {
			parseError("expecting '" + expectedType +
					"' but found '" + this._currentToken.getTokenType() + "'");
		}
	}

	private void acceptIt() throws SyntaxError {
		accept(this._currentToken.getTokenType());
	}


	private void parseError(String e) throws SyntaxError {
		_errors.reportError(0,0,"Parse error: " + e);
		throw new SyntaxError();
	}
	
	private void pTrace() {
		StackTraceElement [] stl = Thread.currentThread().getStackTrace();
		for (int i = stl.length - 1; i > 0 ; i--) {
			if(stl[i].toString().contains("parse"))
				System.out.println(stl[i]);
		}
		System.out.println("accepting: " + this._currentToken.getTokenType() + " (\"" + this._currentToken.getTokenText() + "\")");
		System.out.println();
	}
}
